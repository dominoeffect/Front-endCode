/*
 * 设置一张卡片的事件监听器。 如果该卡片被点击：--OK
 *  - 显示卡片的符号（将这个功能放在你从这个函数中调用的另一个函数中）--OK
 *  - 将卡片添加到状态为 “open” 的 *数组* 中（将这个功能放在你从这个函数中调用的另一个函数中）--another method
 *  - 如果数组中已有另一张卡，请检查两张卡片是否匹配  --anaother method
 *    + 如果卡片匹配，将卡片锁定为 "open" 状态（将这个功能放在你从这个函数中调用的另一个函数中）--another method
 *    + 如果卡片不匹配，请将卡片从数组中移除并隐藏卡片的符号（将这个功能放在你从这个函数中调用的另一个函数中）--another method
 *    + 增加移动计数器并将其显示在页面上（将这个功能放在你从这个函数中调用的另一个函数中）--another mothod
 *    + 如果所有卡都匹配，则显示带有最终分数的消息（将这个功能放在你从这个函数中调用的另一个函数中）--another method
 */

window.onload=function click_turn_over(){

            shuffle_all()

                storage=window.localStorage;
                storage.setItem("countAll",0);
                storage.setItem("success_couple",0);
                storage.setItem("score_point",0);

                document.getElementById('moves_counts').innerHTML = storage.countAll;
                document.getElementById('score').innerHTML = storage.score_point;


                var clear_counts=document.getElementById("clear_counts");
                clear_counts.addEventListener('click', function() { 
                    clear_count()
                }, false);

                var click_count = 0;
                var cards1_1=document.getElementById("cards1_1");
                cards1_1.addEventListener('click', function() { 
                
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards1_1",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards1_1","",click_count);
                        aaa = "cards1_1";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards1_2=document.getElementById("cards1_2");
                cards1_2.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards1_2",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards1_2","",click_count);
                        aaa = "cards1_2";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards1_3=document.getElementById("cards1_3");
                cards1_3.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards1_3",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards1_3","",click_count);
                        aaa = "cards1_3";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards1_4=document.getElementById("cards1_4");
                cards1_4.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards1_4",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards1_4","",click_count);
                        aaa = "cards1_4";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards2_1=document.getElementById("cards2_1");
                cards2_1.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards2_1",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards2_1","",click_count);
                        aaa = "cards2_1";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards2_2=document.getElementById("cards2_2");
                cards2_2.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards2_2",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards2_2","",click_count);
                        aaa = "cards2_2";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards2_3=document.getElementById("cards2_3");
                cards2_3.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards2_3",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards2_3","",click_count);
                        aaa = "cards2_3";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards2_4=document.getElementById("cards2_4");
                cards2_4.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards2_4",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards2_4","",click_count);
                        aaa = "cards2_4";
                    }
                }, false);//给背面朝上的方块注册了onclick事件
                
                var cards3_1=document.getElementById("cards3_1");
                cards3_1.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards3_1",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards3_1","",click_count);
                        aaa = "cards3_1";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards3_2=document.getElementById("cards3_2");
                cards3_2.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards3_2",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards3_2","",click_count);
                        aaa = "cards3_2";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards3_3=document.getElementById("cards3_3");
                cards3_3.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards3_3",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards3_3","",click_count);
                        aaa = "cards3_3";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards3_4=document.getElementById("cards3_4");
                cards3_4.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards3_4",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards3_4","",click_count);
                        aaa = "cards3_4";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

                var cards4_1=document.getElementById("cards4_1");
                cards4_1.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards4_1",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards4_1","",click_count);
                        aaa = "cards3_1";
                    }
                }, false);//给背面朝上的方块注册了onclick事件
                
                var cards4_2=document.getElementById("cards4_2");
                cards4_2.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards4_2",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards4_2","",click_count);
                        aaa = "cards4_2";
                    }
                }, false);//给背面朝上的方块注册了onclick事件
                var cards4_3=document.getElementById("cards4_3");
                cards4_3.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards4_3",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards4_3","",click_count);
                        aaa = "cards4_3";
                    }
                }, false);//给背面朝上的方块注册了onclick事件    

                var cards4_4=document.getElementById("cards4_4");
                cards4_4.addEventListener("click", function() {
                    click_counts();
                    click_count = ++click_count;
                    // alert(click_count) 
                    if(click_count == 2){
                        showfront(aaa,"cards4_4",click_count);
                        click_count = 0;
                    }else{
                        showfront("cards4_4","",click_count);
                        aaa = "cards4_4";
                    }
                }, false);//给背面朝上的方块注册了onclick事件

}
                


function showfront(cards_id_1,cards_id_2,counts) {
    // alert(counts);
	if(counts != 2){
		document.getElementById(cards_id_1).setAttribute("class","card match");
        var card_1 = cards_id_1 ;	
	}else {
        document.getElementById(cards_id_2).setAttribute("class","card match");
        var card_2 = cards_id_2 ; 
        var card_1 = cards_id_1 ; 
        setTimeout(function() {
            compare(card_1,card_2);    
        },700);
	}
}
	
	

function compare(card_one,card_two){
	var card_one_class=document.getElementById(card_one+"_content").getAttribute("class");
	var card_two_class=document.getElementById(card_two+"_content").getAttribute("class");
    
	
    if (card_one_class != card_two_class){
		document.getElementById(card_one).setAttribute("class","card");
		document.getElementById(card_two).setAttribute("class","card");
        storage.setItem('score_point',parseInt(storage.score_point) - 5);
	    document.getElementById('score').innerHTML = storage.score_point;
    }else{
        document.getElementById(card_one).setAttribute("class","card open show");
        document.getElementById(card_two).setAttribute("class","card open show");
        storage.success_couple++;
        storage.setItem('score_point',parseInt(storage.score_point) + 10);
        document.getElementById('score').innerHTML = storage.score_point;
        if(storage.success_couple == 8) {
            alert("You have finished M-GAME! You score is " + storage.score_point);
        }
    }
    
}

function click_counts() {
    storage=window.localStorage;
    storage.countAll++;
    document.getElementById('moves_counts').innerHTML = storage.countAll;

}

function clear_count() {
    window.location.reload();
}

/*
 * 创建一个包含所有卡片的数组
 */
var cards = new Array();
cards[0] = "cards1_1";
cards[1] = "cards1_2";
cards[2] = "cards1_3";
cards[3] = "cards1_4";

cards[4] = "cards2_1";
cards[5] = "cards2_2";
cards[6] = "cards2_3";
cards[7] = "cards2_4";

cards[8] = "cards3_1";
cards[9] = "cards3_2";
cards[10] = "cards3_3";
cards[11] = "cards3_4";

cards[12] = "cards4_1";
cards[13] = "cards4_2";
cards[14] = "cards4_3";
cards[15] = "cards4_4";

/*
 * 显示页面上的卡片
 *   - 使用下面提供的 "shuffle" 方法对数组中的卡片进行洗牌
 *   - 循环遍历每张卡片，创建其 HTML
 *   - 将每张卡的 HTML 添加到页面
 */

// 洗牌函数来自于 http://stackoverflow.com/a/2450976
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}


function shuffle_all() {

    shuffle(cards);

    document.getElementById(cards[0]+'_content').setAttribute("class","fa fa-diamond");
    document.getElementById(cards[1]+'_content').setAttribute("class","fa fa-diamond");
    document.getElementById(cards[2]+'_content').setAttribute("class","fa fa-paper-plane-o");
    document.getElementById(cards[3]+'_content').setAttribute("class","fa fa-paper-plane-o");
    
    document.getElementById(cards[4]+'_content').setAttribute("class","fa fa-anchor");
    document.getElementById(cards[5]+'_content').setAttribute("class","fa fa-anchor");
    document.getElementById(cards[6]+'_content').setAttribute("class","fa fa-bolt");
    document.getElementById(cards[7]+'_content').setAttribute("class","fa fa-bolt");

    document.getElementById(cards[8]+'_content').setAttribute("class","fa fa-cube");
    document.getElementById(cards[9]+'_content').setAttribute("class","fa fa-cube");
    document.getElementById(cards[10]+'_content').setAttribute("class","fa fa-bomb");
    document.getElementById(cards[11]+'_content').setAttribute("class","fa fa-bomb");

    document.getElementById(cards[12]+'_content').setAttribute("class","fa fa-leaf");
    document.getElementById(cards[13]+'_content').setAttribute("class","fa fa-leaf");
    document.getElementById(cards[14]+'_content').setAttribute("class","fa fa-bicycle");
    document.getElementById(cards[15]+'_content').setAttribute("class","fa fa-bicycle");

}











